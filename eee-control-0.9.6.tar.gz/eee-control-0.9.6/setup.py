#!/usr/bin/env python

from distutils.core import setup, Extension
import glob
import os

setup(  name="eee-control",
        version="0.9.6",
        
        packages=["EeeControl"],
        scripts=["eee-control-daemon", "eee-control-tray", "eee-control-query", "eee-control-setup.sh", "eee-dispswitch.sh"],
        data_files=[
            ("share/eee-control", glob.glob("data/*.png")),            
            ("../etc/dbus-1/system.d", ["data/eee-control-daemon.conf"]),
            ("share/eee-control", ["data/eee-control.conf"]),
            ("share/applications", ["data/eee-control-tray.desktop"]),
            ("../etc/xdg/autostart", ["data/eee-control-tray.desktop"]),
            ("share/gconf/schemas", ["data/eee-control.schemas"]),
            ("share/locale/de/LC_MESSAGES", ["locale/de/LC_MESSAGES/eee-control.mo"]),
            ("share/locale/hu/LC_MESSAGES", ["locale/hu/LC_MESSAGES/eee-control.mo"]),
            ("share/locale/fr/LC_MESSAGES", ["locale/fr/LC_MESSAGES/eee-control.mo"]),
            ("share/locale/es/LC_MESSAGES", ["locale/es/LC_MESSAGES/eee-control.mo"]),
            ("share/locale/ca/LC_MESSAGES", ["locale/ca/LC_MESSAGES/eee-control.mo"]),
            ("share/locale/ru/LC_MESSAGES", ["locale/ru/LC_MESSAGES/eee-control.mo"]),
            ("share/locale/it/LC_MESSAGES", ["locale/it/LC_MESSAGES/eee-control.mo"]),
            ("share/locale/zh_HK/LC_MESSAGES", ["locale/zh_HK/LC_MESSAGES/eee-control.mo"]),
            ("share/locale/zh_TW/LC_MESSAGES", ["locale/zh_TW/LC_MESSAGES/eee-control.mo"]),
            ("share/locale/nb/LC_MESSAGES", ["locale/nb/LC_MESSAGES/eee-control.mo"]),
            ("share/locale/fa/LC_MESSAGES", ["locale/fa/LC_MESSAGES/eee-control.mo"]),
            ("share/locale/sv/LC_MESSAGES", ["locale/sv/LC_MESSAGES/eee-control.mo"]),
        ],
	ext_modules=[Extension('EeeControl.ioport', sources=["ioport/ioport.c"])],
)
