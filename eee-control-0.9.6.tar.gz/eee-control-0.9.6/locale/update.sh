#!/bin/sh
# Update binary translation (.mo) files
cd $(dirname $0)

for i in *.po; do
	echo processing $i
	LANGCODE=$(echo $i | sed 's/.po$//')
	mkdir -p ${LANGCODE}/LC_MESSAGES
	msgfmt -o ${LANGCODE}/LC_MESSAGES/eee-control.mo $i
done
