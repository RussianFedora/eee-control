#!/bin/sh
# Update .pot file
cd $(dirname $0)

# Create .pot file
xgettext -k_ -kN_ -o eee-control.pot ../EeeControl/*.py

# Update all translations
for i in *.po; do
	msgmerge -U $i eee-control.pot
done
