/* $Id: ioport.c,v 1.2 2000/06/27 09:47:11 lsmithso Exp $ 
 * Python extension for Linux port i/o, using ioperm/outb/inb etc.
 *
 * Author: L. Smithson (lsmithson@open-networks.co.uk)
 *
 * DISCLAIMER
 * You are free to use this code in any way you like, subject to the
 * Python disclaimers & copyrights. I make no representations about
 * the suitability of this software for any purpose. It is provided
 * "AS-IS" without warranty of any kind, either express or implied. So
 * there.
 */

/***********************************************************
Copyright 1991-1995 by Stichting Mathematisch Centrum, Amsterdam,
The Netherlands.

                        All Rights Reserved

Permission to use, copy, modify, and distribute this software and its
documentation for any purpose and without fee is hereby granted,
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in
supporting documentation, and that the names of Stichting Mathematisch
Centrum or CWI or Corporation for National Research Initiatives or
CNRI not be used in advertising or publicity pertaining to
distribution of the software without specific, written prior
permission.

While CWI is the initial source for this software, a modified version
is made available by the Corporation for National Research Initiatives
(CNRI) at the Internet address ftp://ftp.python.org.

STICHTING MATHEMATISCH CENTRUM AND CNRI DISCLAIM ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE, INCLUDING ALL IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL STICHTING MATHEMATISCH
CENTRUM OR CNRI BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL
DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR
PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.

******************************************************************/

#include <sys/io.h>
#include "Python.h"

/*

- Added iopl wrapper
- Relaxed validation to ports up to 0xffff
- Switch to *_p flavors of the IO functions

  - Grigori Goronzy, 2008-12-06 01:26:37 

*/

static PyObject *ErrorObj;

/* ----------------------------------------------------- */

/*
 * Helper func that validates port. Sets exceptiuon & returns 1 if
 * valid, 0 otherwise
 */

static int validate(int port) {
  if ((port < 0) || (port > 0xffff)) {
    PyErr_SetString(ErrorObj, "Invalid port address");
    return 0;
  }
  return 1;
}

static char iop_outb__doc__[] = "outb(value, port)\n\nOutput the byte 'value' to io port 'port'." ;

static PyObject *iop_outb(PyObject *self, PyObject *args) {
  unsigned char value;
  int port;
  
  if (!PyArg_ParseTuple(args, "bi", &value, &port ))
    return NULL;

  if (!validate(port)) {
    return NULL;
  }

  /* Do the port IO */
  outb_p(value, port);

  Py_INCREF(Py_None);
  return Py_None;
}

static char iop_inb__doc__[] = "inb(port)\n\nReturn a byte with the input read from 'port'." ;

static PyObject *iop_inb(PyObject *self, PyObject *args) {
  unsigned char value;
  int port;

  if (!PyArg_ParseTuple(args, "i", &port))
    return NULL;

  if (!validate(port)) {
    return NULL;
  }

  /* Read the port */
  value = inb_p(port);

  return Py_BuildValue("b", value);
}


static char iop_ioperm__doc__[] = "ioperm(port, len, onoff)\n\nTurn onoff ioperm for calling process for port block at 'port', length 'len'.";

static PyObject *iop_ioperm(PyObject *self, PyObject *args) {
  int port;
  int len;
  int onoff;

  if (!PyArg_ParseTuple(args, "iii", &port, &len, &onoff))
    return NULL;

  if (!validate(port)) {
    return NULL;
  }

  if (ioperm(port, len, onoff) < 0) {
    PyErr_Format(ErrorObj, "Errno %d - %s", errno, strerror(errno));
    return NULL;
  }
  
  Py_INCREF(Py_None);
  return Py_None;
}

static char iop_iopl__doc__[] = "iopl(level)\n\nSet process I/O privilege level; Linux specific.";

static PyObject *iop_iopl(PyObject *self, PyObject *args) {
    int level;

    if (!PyArg_ParseTuple(args, "i", &level))
        return NULL;
        
    if (level > 3 || level < 0) {
        PyErr_Format(ErrorObj, "Invalid privilege level");
        return NULL;
    }
    
    if (iopl(level) == -1) {
        PyErr_Format(ErrorObj, "Failed with return value %d", errno);
        return NULL;
    }
        
    Py_INCREF(Py_None);
    return Py_None;
}

/* List of methods defined in the module */

static struct PyMethodDef iop_methods[] = {
  {"outb", (PyCFunction)iop_outb, METH_VARARGS,	iop_outb__doc__},
  {"inb", (PyCFunction)iop_inb,	METH_VARARGS, iop_inb__doc__},
  {"ioperm", (PyCFunction)iop_ioperm, METH_VARARGS, iop_ioperm__doc__},
  {"iopl", (PyCFunction)iop_iopl, METH_VARARGS, iop_iopl__doc__},
  {NULL, (PyCFunction)NULL, 0, NULL}		/* sentinel */
};


/* Initialization function for the module (*must* be called initioport) */

static char ioport_module_documentation[] = "ioport - A Python extension for input/output to hardware ports. Ioport is a simple wrapper for the Linux ioperm/outb/inb calls, and it shares many of their characteristics & limitations. In particular, Python will segfault if you attempt i/o without calling ioperm first. See the Linux IO-Port-Programming Mini-HOWTO by Riku Saikkonen\n (Riku.Saikkonen@hut.fi) for more details.\n\nThe following calls are supported:\nioperm(port, len, onoff)\noutb(value, port)\ninb(port)";

void initioport(void) {
  PyObject *m, *d;
  /* Create the module and add the functions */
  m = Py_InitModule4("ioport", iop_methods,
		     ioport_module_documentation,
		     (PyObject*)NULL,PYTHON_API_VERSION);
  
  /* Add some symbolic constants to the module */
  d = PyModule_GetDict(m);
  ErrorObj = PyString_FromString("ioport.error");
  PyDict_SetItemString(d, "error", ErrorObj);

  PyDict_SetItemString(d, "__doc__", PyString_FromString(ioport_module_documentation));

  /* XXXX Add constants here */
  
  /* Check for errors */
  if (PyErr_Occurred())
    Py_FatalError("can't initialize module ioport");
}
 
