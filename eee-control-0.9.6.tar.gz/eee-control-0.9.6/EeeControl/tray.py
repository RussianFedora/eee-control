# -*- coding: utf-8 -*-
# 
# Copyright (c) 2008-2009 Grigori Goronzy <greg@geekmind.org>
#
# Permission to use, copy, modify, and distribute this software for any
# purpose with or without fee is hereby granted, provided that the above
# copyright notice and this permission notice appear in all copies.
#
# THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
# WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
# ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
# WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
# ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
# OR IN CONNECTION WITH THE USE OR PERFORMANCE OF  THIS SOFTWARE.
#  

import dbus
import dbus.decorators
import dbus.mainloop.glib
import gtk
import gobject
import pynotify
import os, sys, commands
import gconf
import signal
import gettext
import utils
    
class EeeControlTray:
    def __init__(self):        
        self.keyword_actions = {
            "toggle-touchpad": self.toggle_touchpad,
            "toggle-performance": self.toggle_fsb,
            "toggle-wifi": self.toggle_wifi,
            "toggle-bluetooth": self.toggle_bluetooth,
            "toggle-camera": self.toggle_camera,
            "toggle-cardreader": self.toggle_reader,
            "display-off": self.screen_off,
            "media-play": self.fake_play,
            "media-stop": self.fake_stop,
            "media-next": self.fake_next,
            "media-previous": self.fake_prev,
        }

        # Enable internationalization
        locale_path = os.path.join(sys.prefix, "share", "locale")
        gettext.install("eee-control", locale_path, unicode=True)
        
        # Determine whether we have a synaptics touchpad
        # and it is accessible
        self.use_synaptics = False
        self.synaptics_state = True
        if os.system("synclient -l >/dev/null 2>/dev/null") == 0:
            self.use_synaptics = True
            
        self.conf = gconf.Client()
        self.makeui()
        self.connect_signals()
        self.tryconnect()
        self.register_notifications()
        signal.signal(signal.SIGCHLD, self.wait_child)
        self.autotriggered = False
        self.config = None
        self.sensors = None
        
    """Kill exited children to avoid zombies"""
    def wait_child(self, signal, frame):
        try: os.waitpid(-1, 0)
        except OSError: pass
        
    def tryconnect(self):
        self.disable_tray()
        try: self.enable_tray()
        except dbus.exceptions.DBusException, e:
            print _("Error communicating with eee-control-daemon: %s") %e
 
    def toggle_touchpad(self):
        # If we're using synaptics, switch it via synclient
        if self.use_synaptics:
            if self.synaptics_state == True:
                os.system("synclient TouchpadOff=1")
                self.synaptics_state = False
            else:
                os.system("synclient TouchpadOff=0")
                self.synaptics_state = True
            self.touchpad_notify(self.synaptics_state)
        else:
            if self.iface.get_touchpad(): self.iface.touchpad_off()
            else: self.iface.touchpad_on()

    def toggle_wifi(self):
        self.iface.wifi_toggle()

    def toggle_bluetooth(self):
        if self.iface.get_bluetooth(): self.iface.bt_off()
        else: self.iface.bt_on()

    def toggle_camera(self):
        if self.iface.get_camera(): self.iface.cam_off()
        else: self.iface.cam_on()
    
    def toggle_reader(self):
        if self.iface.get_reader():
            if self.unmount_reader():
                self.iface.reader_off()
            else:
                self.info_notify(_("Cannot unmount card reader!"), icon=utils.get_file("card-reader.png"))
                self.block_all()
                self.reader_check.set_active(True)                
                self.unblock_all()
        else: self.iface.reader_on()

    def screen_off(self):
        os.spawnlp(os.P_NOWAIT, "xset", "xset", "dpms", "force", "off")

    def toggle_fsb(self):
        if self.iface.get_fsb == None: return
        cur_fsb = self.iface.get_fsb()
        all_fsb = self.iface.get_fsb_presets()
        i = all_fsb.index(cur_fsb)
        if i < len(all_fsb)-1: new_fsb = all_fsb[i+1]
        else: new_fsb = all_fsb[0]
        self.iface.set_fsb(new_fsb)
    
    # Fake media keys
    def fake_play(self): self.iface.fakekey(164)
    def fake_stop(self): self.iface.fakekey(166)
    def fake_next(self): self.iface.fakekey(163)
    def fake_prev(self): self.iface.fakekey(165)
    
    def makeui(self):
        # Create the tray icon
        self.icon_pixbuf = gtk.gdk.pixbuf_new_from_file(utils.get_file("eee-icon.png"))
        self.icon = gtk.StatusIcon()
        self.icon.set_from_pixbuf(self.icon_pixbuf)
        self.icon.connect("activate", self.standard_menu_show)
        self.icon.connect("popup-menu", self.popup_menu_show)
        
        # Add the menus
        self.standard_menu = gtk.Menu()
        self.wifi_check = gtk.CheckMenuItem(_("WiFi"))
        self.standard_menu.append(self.wifi_check)
        self.bt_check = gtk.CheckMenuItem(_("Bluetooth"))
        self.standard_menu.append(self.bt_check)
        self.camera_check = gtk.CheckMenuItem(_("Camera"))
        self.standard_menu.append(self.camera_check)        
        self.reader_check = gtk.CheckMenuItem(_("Card Reader"))
        self.standard_menu.append(self.reader_check)                
        self.standard_menu.append(gtk.SeparatorMenuItem())
        self.fsb_menu = gtk.Menu()
        self.fsb_menuitem = gtk.MenuItem(_("Performance"))
        self.fsb_menuitem.set_submenu(self.fsb_menu)
        self.standard_menu.append(self.fsb_menuitem)
        self.standard_menu.show_all()

        self.popup_menu = gtk.Menu()
        self.preferences_button = gtk.ImageMenuItem(stock_id=gtk.STOCK_PREFERENCES) 
        self.popup_menu.append(self.preferences_button)
        self.about_button = gtk.ImageMenuItem(stock_id=gtk.STOCK_ABOUT)
        self.popup_menu.append(self.about_button)
        self.sensors_button = gtk.MenuItem(_("Sensors"))
        self.popup_menu.append(self.sensors_button)
        self.popup_menu.show_all()
 
    def connect_signals(self):
        self.block_list = []
        self.wifi_check.connect("toggled", self.wifi_toggled)
        self.block_list.append((self.wifi_check, self.wifi_toggled))
        self.bt_check.connect("toggled", self.bt_toggled)
        self.block_list.append((self.bt_check, self.bt_toggled))
        self.camera_check.connect("toggled", self.camera_toggled)
        self.block_list.append((self.camera_check, self.camera_toggled))
        self.reader_check.connect("toggled", self.reader_toggled)
        self.block_list.append((self.reader_check, self.reader_toggled))
        self.about_button.connect("activate", self.about_dialog)
        self.preferences_button.connect("activate", self.config_dialog)
        self.sensors_button.connect("activate", self.sensors_dialog)
    
    def block_all(self):
        for widget, func in self.block_list:
            widget.handler_block_by_func(func)
    
    def unblock_all(self):
        for widget, func in self.block_list:
            widget.handler_unblock_by_func(func)
        
    def populate_fsb_menu(self):
        for c in self.fsb_menu.get_children():
            self.fsb_menu.remove(c)
            self.block_list.remove((c, self.update_fsb))
            
        presets = self.iface.get_fsb_presets()
        group = None
        for p in presets:
            i = gtk.RadioMenuItem(group, p)
            self.fsb_menu.append(i)
            group = i
        
        # Disable everything if FSB control is not available
        active = True
        if self.iface.get_fsb() == None: active = False
        self.fsb_menu.show_all()
        
        for c in self.fsb_menu.get_children():
            c.set_sensitive(active)
            c.connect("activate", self.update_fsb)
            self.block_list.append((c, self.update_fsb))
    
    def update_fsb(self, widget):
        if widget.get_active() == False: return
        self.iface.set_fsb(widget.get_child().get_text())
        
    def initialize_hwinfo(self):
        self.block_all()
        features = self.iface.get_features()
        self.standard_menu.show_all()
        if not "wifi" in features:
            self.wifi_check.hide()
        else: self.wifi_check.set_active(self.iface.get_wifi())
        if not "bt" in features:
            self.bt_check.hide()
        else: self.bt_check.set_active(self.iface.get_bluetooth())
        if not "camera" in features:
            self.camera_check.hide()
        else: self.camera_check.set_active(self.iface.get_camera())
        if not "reader" in features:
            self.reader_check.hide()
        else: self.reader_check.set_active(self.iface.get_reader())
        fsb = self.iface.get_fsb()
        if fsb:
            for c in self.fsb_menu.get_children():
                if c.get_child().get_text() == fsb:
                    c.set_active(True)
        self.unblock_all()

    def config_dialog(self, widget):
        if self.config != None:
            self.config.present()
        else:
            self.config = EeeControlTrayConfiguration(self)
            self.config.show()
    
    def sensors_dialog(self, widget):
        if self.sensors != None:
            self.sensors.present()
        else:
            self.sensors = EeeControlSensors(self)
            self.sensors.show()
       
    def about_dialog(self, widget):
        version, model = self.iface.info()
        
        d = gtk.AboutDialog()
        d.set_name("eee-control-tray")
        d.set_version(utils.VERSION)
        d.set_copyright("Copyright (C) 2008-2010 Grigori Goronzy")
        d.set_comments(_("eee-control-tray is a utility for controlling Eee PC hardware, hotkeys and more through eee-control-daemon.\n\nNetbook Model: %s\neee-control-daemon version: %s") %(model, version))
        d.set_logo(self.icon_pixbuf)
        d.set_icon(self.icon_pixbuf)
        d.set_website("http://greg.geekmind.org/eee-control/")
        d.run()
        d.destroy()
        
    def standard_menu_show(self, icon):
        et = gtk.get_current_event_time()
        self.standard_menu.popup(None, None, gtk.status_icon_position_menu,
            1, et, icon)
    
    def popup_menu_show(self, icon, button, at):
        self.popup_menu.popup(None, None, gtk.status_icon_position_menu,
            button, at, icon)
    
    def dbus_connect(self):
        dbus.mainloop.glib.DBusGMainLoop(set_as_default=True)
        self.bus = dbus.SystemBus()
        self.remote = self.bus.get_object("org.eee.Eee", "/org/eee/Eee/EeePc")
        self.iface = dbus.Interface(self.remote, dbus_interface="org.eee.Eee")
        
    def register_notifications(self):
        pynotify.init("eee-control")
        self.notify = pynotify.Notification("(empty)")
        self.notify.set_urgency(pynotify.URGENCY_LOW)
        self.notify.attach_to_status_icon(self.icon)
        
        self.bus.add_signal_receiver(self.wifi_notify, dbus_interface="org.eee.Eee", signal_name="wifi_changed")
        self.bus.add_signal_receiver(self.touchpad_notify, dbus_interface="org.eee.Eee", signal_name="touchpad_changed")
        self.bus.add_signal_receiver(self.hotkey_execute, dbus_interface="org.eee.Eee", signal_name="hotkey_pressed")
        self.bus.add_signal_receiver(self.bt_notify, dbus_interface="org.eee.Eee", signal_name="bluetooth_changed")
        self.bus.add_signal_receiver(self.camera_notify, dbus_interface="org.eee.Eee", signal_name="camera_changed")
        self.bus.add_signal_receiver(self.reader_notify, dbus_interface="org.eee.Eee", signal_name="reader_changed")
        self.bus.add_signal_receiver(self.fsb_notify, dbus_interface="org.eee.Eee", signal_name="fsb_changed")
        # Listen for eee-control-daemon appearance/disappearance
        self.bus.add_signal_receiver(self.daemon_status_change, dbus_interface="org.freedesktop.DBus", signal_name="NameOwnerChanged", arg0="org.eee.Eee")
        # Listen for upower (autofsb)
        # This can safely fail
        try:
            self.bus.add_signal_receiver(self.autofsb_trigger, dbus_interface="org.freedesktop.UPower", signal_name="Changed")
            self.bus.add_signal_receiver(self.autofsb_start, dbus_interface="org.freedesktop.DBus", signal_name="NameOwnerChanged", arg0="org.freedesktop.UPower")
        except dbus.exceptions.DBusException:
            print _("Unable to set up autofsb signal receiver.")
    
    def daemon_status_change(self, name, oldown, newown):
        if newown == "": self.disable_tray()
        if oldown == "": self.enable_tray(notify=True)
    
    def autofsb_start(self, name, oldown, newown):
        if oldown == "":
            self.apply_configuration()
            
    def autofsb_trigger(self):
        remote = self.bus.get_object("org.freedesktop.UPower", "/org/freedesktop/UPower")
        iface = dbus.Interface(remote, dbus_interface="org.freedesktop.DBus.Properties")
        state = iface.Get("org.freedesktop.UPower", "OnBattery")
        if self.conf.get_bool("/apps/eee-control-tray/options/autofsb") and self.iface.get_fsb() != None:
            if state == True:
                self.iface.set_fsb("powersave")
                self.autotriggered = True
            else:
                fsb = self.conf.get_string("/apps/eee-control-tray/fsb_preset")
                if fsb != None:
                    self.iface.set_fsb(fsb)
                else:
                    # Fallback if no presets have been saved yet
                    self.iface.set_fsb("normal")
    
    def disable_tray(self):
        self.icon.handler_block_by_func(self.standard_menu_show)
        self.icon.handler_block_by_func(self.popup_menu_show)
        self.icon.set_tooltip(_("Error while communicating with eee-control-daemon!\nMake sure it is running."))
    
    def enable_tray(self, notify=False):
        self.dbus_connect()
        self.icon.handler_unblock_by_func(self.standard_menu_show)
        self.icon.handler_unblock_by_func(self.popup_menu_show)
        if not self.check_modifier():
            self.apply_configuration()
        self.populate_fsb_menu()
        self.initialize_hwinfo()
        self.update_tooltip()
        if notify:
            self.info_notify(_("eee-control-daemon connected."), icon=utils.get_file("eee-icon-small.png"))
        
    def update_tooltip(self):
        fsb = self.iface.get_fsb()
        if fsb == None:
            fsb = _("not available")
        m = { True: _("on"), False: _("off") }
        tooltip_text = _("WiFi: %s\nBluetooth: %s\nCamera: %s\nCard Reader: %s\nPerformance: %s") % (
            m[self.wifi_check.get_active()],
            m[self.bt_check.get_active()],
            m[self.camera_check.get_active()],
            m[self.reader_check.get_active()],
            fsb
            )
        self.icon.set_tooltip(tooltip_text)
    
    def apply_configuration(self):
        n = self.conf.get_bool("/apps/eee-control-tray/options/fan_control")
        self.iface.set_fan_control(n)
        # Switch to powersave preset if autofsb is active
        if self.conf.get_bool("/apps/eee-control-tray/options/autofsb") == True:
            try:
                remote = self.bus.get_object("org.freedesktop.UPower", "/org/freedesktop/UPower")
                iface = dbus.Interface(remote, dbus_interface="org.freedesktop.DBus.Properties")
                if iface.Get("org.freedesktop.UPower", "OnBattery") == True and self.iface.get_fsb() != None:
                    self.autotriggered = True
                    self.iface.set_fsb("powersave")
                    return False
            except dbus.exceptions.DBusException:
                print _("Failed to set up automatic performance adjustment.")
        # Else, apply saved FSB
        preset = self.conf.get_string("/apps/eee-control-tray/fsb_preset")
        if preset and self.iface.get_fsb() != None:
            self.iface.set_fsb(preset)
        return False
    
    """Check whether user has CTRL pressed, and if so display a neat dialog, informing the user that FSB control was disabled"""
    def check_modifier(self):
        d = gtk.gdk.display_get_default()
        p = d.get_pointer()
        if p[3] & gtk.gdk.CONTROL_MASK:
            m = gtk.MessageDialog(flags=gtk.DIALOG_MODAL, buttons=gtk.BUTTONS_CLOSE, message_format=_("Performance adjustments were disabled because you held down CTRL while eee-control started."), type=gtk.MESSAGE_WARNING)
            m.set_icon(self.icon_pixbuf)
            m.set_title(_("Performance adjustments disabled"))
            m.show()
            m.run()
            m.destroy()
            return True
        return False
            
    def hotkey_execute(self, key, descr):
        what = self.conf.get_string("/apps/eee-control-tray/hotkeys/hotkey-%s" %str(key))
        if what == None: return
        elif what in self.keyword_actions.keys():
            func = self.keyword_actions[what]
            func()
        else:
            args = what.split(" ")
            os.spawnvp(os.P_NOWAIT, args[0], args)
        
    def wifi_notify(self, state):
        self.block_all()
        self.wifi_check.set_active(state)
        self.unblock_all()
        self.update_tooltip()
        if self.conf.get_bool("/apps/eee-control-tray/notify/wifi") == False: return
        if state: title = _("WiFi switched on")
        else: title = _("WiFi switched off")
        self.info_notify(title, icon=utils.get_file("wifi.png"))

    def touchpad_notify(self, state):
        if self.conf.get_bool("/apps/eee-control-tray/notify/pad") == False: return
        if state: title = _("Touchpad switched on")
        else: title = _("Touchpad switched off")
        self.info_notify(title, icon=utils.get_file("touchpad.png"))        

    def bt_notify(self, state):
        self.block_all()
        self.bt_check.set_active(state)
        self.unblock_all()
        self.update_tooltip()
        if self.conf.get_bool("/apps/eee-control-tray/notify/bt") == False: return
        if state: title = _("Bluetooth switched on")
        else: title = _("Bluetooth switched off")
        self.info_notify(title, icon=utils.get_file("bluetooth.png"))

    def camera_notify(self, state):
        self.block_all()
        self.camera_check.set_active(state)
        self.unblock_all()
        self.update_tooltip()
        if self.conf.get_bool("/apps/eee-control-tray/notify/cam") == False: return
        if state: title = _("Camera switched on")
        else: title = _("Camera switched off")
        self.info_notify(title, icon=utils.get_file("camera.png"))        

    def reader_notify(self, state):
        self.block_all()
        self.reader_check.set_active(state)
        self.unblock_all()
        self.update_tooltip()
        if self.conf.get_bool("/apps/eee-control-tray/notify/reader") == False: return
        if state: title = _("Card reader switched on")
        else: title = _("Card reader switched off")
        self.info_notify(title, icon=utils.get_file("card-reader.png"))
        
    def fsb_notify(self, preset):
        self.block_all()
        for c in self.fsb_menu.get_children():
            if c.get_child().get_text() == preset:
                c.set_active(True)
        self.unblock_all()
        self.update_tooltip()
        # Save preset
        if not self.autotriggered:
            self.conf.set_string("/apps/eee-control-tray/fsb_preset", preset)
        else:
            self.autotriggered = False
        if self.conf.get_bool("/apps/eee-control-tray/notify/fsb") == False: return
        self.info_notify(_("Performance changed to '%s'") % preset, icon=utils.get_file("performance.png"))
        
    def fan_notify(self, state):
        if self.conf.get_bool("/apps/eee-control-tray/notify/fan") == False: return
        if state: title = _("Fan switched on")
        else: title = _("Fan switched off")
        self.info_notify(title)
    
    def info_notify(self, text, body=None, icon=None):
        self.notify.update(_("eee-control"), text, icon)
        self.notify.show()
        
    def wifi_toggled(self, widget):
        self.iface.wifi_toggle()
    
    def bt_toggled(self, widget):
        if widget.get_active(): self.iface.bt_on()
        else: self.iface.bt_off()

    def camera_toggled(self, widget):
        if widget.get_active(): self.iface.cam_on()
        else: self.iface.cam_off()
        
    def unmount_reader(self):
        remote = self.bus.get_object("org.freedesktop.UDisks", "/org/freedesktop/UDisks")
        udisks = dbus.Interface(remote, dbus_interface="org.freedesktop.UDisks")
        for dev in udisks.EnumerateDevices():
            remote = self.bus.get_object("org.freedesktop.UDisks", dev)
            device = dbus.Interface(remote, dbus_interface="org.freedesktop.DBus.Properties")
            if not device.Get("org.freedesktop.UDisks.Device", "DeviceIsMounted"): continue
            devname = device.Get("org.freedesktop.UDisks.Device", "DriveModel")
            # Hopefully matching the device this way is Good Enough (tm)
            if devname.find("Flash Reader") >= 0 or devname.find("CardReader") >= 0:
                device = dbus.Interface(remote, "org.freedesktop.UDisks.Device")
                try:
                    device.FilesystemUnmount([])
                except Exception, e:
                    print _("Unmount failed with %s") % e
                    return False
        return True

    def reader_toggled(self, widget):
        if widget.get_active(): self.iface.reader_on()
        else: 
            # Unmount volumes on the card reader before turning it off
            if self.unmount_reader():
                self.iface.reader_off()
            else:
                self.block_all()
                self.reader_check.set_active(True)
                self.unblock_all()
                self.info_notify(_("Cannot unmount card reader!"), icon=utils.get_file("card-reader.png"))


"""Display a simple, self-updating window with sensors information"""
class EeeControlSensors(gtk.Dialog):
    def __init__(self, tray):
        gtk.Dialog.__init__(self, title="Sensors")
        self.set_icon(tray.icon_pixbuf)
        self.tray = tray
        self.makeui()
        self.update()
        self.source = gobject.timeout_add(1000, self.update)
    
    def makeui(self):
        self.set_has_separator(False)
        self.set_resizable(False)
        table = gtk.Table(rows=3, columns=2)
        temp_lbl = gtk.Label(_("Temperature"))
        temp_lbl.set_alignment(0.0, 0.5)
        table.attach(temp_lbl, 0, 1, 0, 1)
        fan_lbl = gtk.Label(_("Fan speed"))
        fan_lbl.set_alignment(0.0, 0.5)
        table.attach(fan_lbl, 0, 1, 1, 2)
        rpm_lbl = gtk.Label(_("Fan RPM"))
        rpm_lbl.set_alignment(0.0, 0.5)
        table.attach(rpm_lbl, 0, 1, 2, 3)
        self.temp = gtk.Label("0 °C")
        self.temp.set_alignment(1.0, 0.5)
        table.attach(self.temp, 1, 2, 0, 1)
        self.fan = gtk.Label("25")
        self.fan.set_alignment(1.0, 0.5)
        table.attach(self.fan, 1, 2, 1, 2)
        self.rpm = gtk.Label("800")
        self.rpm.set_alignment(1.0, 0.5)
        table.attach(self.rpm, 1, 2, 2, 3)
        table.set_row_spacings(8)
        table.set_col_spacings(30)
        table.set_border_width(10)
        self.vbox.pack_start(table)
        self.vbox.show_all()
        self.connect("response", lambda x, y: self.close())
        self.connect("close", lambda x: self.close())

    def update(self):
        temp = self.tray.iface.get_temperature()
        fan, rpm = self.tray.iface.get_fan_speed()
        self.temp.set_text("%d °C" %int(temp))
        self.fan.set_text(str(fan))
        self.rpm.set_text(str(rpm))
        return True
    
    def close(self):
        gobject.source_remove(self.source)
        self.tray.sensors = None
        self.destroy()
        
                     
class EeeControlTrayConfiguration(gtk.Dialog):        
    def __init__(self, tray):
        self._ready = True
        gtk.Dialog.__init__(self, title=_("Preferences"),
            buttons=(gtk.STOCK_CLOSE, gtk.RESPONSE_ACCEPT))
        self.set_icon(tray.icon_pixbuf)
        self.tray = tray
        # Shortcuts
        self.iface = self.tray.iface
        self.conf = self.tray.conf
        self.makeui()
    
    def makeui(self):
        self.set_has_separator(False)
        self.set_resizable(False)
        
        # The three main frames
        hotkey_frame = self.make_frame(_("Hotkeys"))
        notify_frame = self.make_frame(_("Notifications"))
        option_frame = self.make_frame(_("Options"))
        self.vbox.pack_start(hotkey_frame)
        self.vbox.pack_start(notify_frame)
        self.vbox.pack_start(option_frame)
        
        # Hotkey frame
        hvbox = gtk.VBox()
        info_lbl = gtk.Label(_("Use one of the predefined keyword actions or enter a command to execute."))
        info_lbl.set_padding(0, 6)
        info_lbl.set_alignment(0.0, 0.5)
        info_lbl.set_line_wrap(True)
        hvbox.pack_start(info_lbl)
        hk_tbl = gtk.Table()
        hk_tbl.set_row_spacings(1)
        hk_tbl.set_col_spacings(10)
        colnum = 0
        hks = self.iface.get_hotkeys().items()
        hks.sort(key=lambda x: x[1])
        for key, descr in hks:
            lbl = gtk.Label(descr)
            lbl.set_alignment(0.0, 0.5)
            hk_tbl.attach(lbl, 0, 1, colnum, colnum+1)
            cbox = self.make_cbox()
            cbox.set_name(str(key))
            t = self.conf.get_string("/apps/eee-control-tray/hotkeys/hotkey-%s" %str(key))
            if not t: cbox.set_active(0)
            else:
                cbox.prepend_text(t)
                cbox.set_active(0)
            cbox.connect("changed", self.hotkey_changed)
            hk_tbl.attach(cbox, 1, 2, colnum, colnum+1)
            colnum += 1
        hvbox.pack_start(hk_tbl)
        hotkey_frame.get_child().add(hvbox)
        
        # Notification frame
        not_tbl = gtk.Table()
        not_tbl.set_homogeneous(True)
        not_tbl.set_border_width(1)
        not_tbl.set_col_spacings(2)
        wifi_button = gtk.CheckButton(_("WiFi"))
        wifi_button.set_name("wifi")
        bt_button = gtk.CheckButton(_("Bluetooth"))
        bt_button.set_name("bt")
        cam_button = gtk.CheckButton(_("Camera"))
        cam_button.set_name("cam")
        reader_button = gtk.CheckButton(_("Card Reader"))
        reader_button.set_name("reader")
        fsb_button = gtk.CheckButton(_("Performance"))
        fsb_button.set_name("fsb")
        pad_button = gtk.CheckButton(_("Touchpad"))
        pad_button.set_name("pad")
        not_tbl.attach(wifi_button, 0, 1, 0, 1)
        not_tbl.attach(bt_button, 1, 2, 0, 1)
        not_tbl.attach(cam_button, 2, 3, 0, 1)
        not_tbl.attach(reader_button, 0, 1, 1, 2)
        not_tbl.attach(fsb_button, 1, 2, 1, 2)
        not_tbl.attach(pad_button, 2, 3, 1, 2)
        notify_frame.get_child().add(not_tbl)
        for c in not_tbl.get_children():
            b = self.conf.get_bool("/apps/eee-control-tray/notify/%s" %c.get_name())
            c.set_active(b)
            c.connect("toggled", self.notify_changed)
        
        # Option frame
        ovbox = gtk.VBox()
        ovbox.set_border_width(1)
        fsb_check = gtk.CheckButton(_("Set performance to powersave on battery"))
        fsb_check.set_active(self.conf.get_bool("/apps/eee-control-tray/options/autofsb"))
        fan_check = gtk.CheckButton(_("Smart fan control"))
        fan_check.set_active(self.conf.get_bool("/apps/eee-control-tray/options/fan_control"))
        fsb_check.connect("toggled", self.autofsb_changed)
        fan_check.connect("toggled", self.fan_control_changed)
        ovbox.pack_start(fsb_check)
        ovbox.pack_start(fan_check)
        option_frame.get_child().add(ovbox)
        
        # Put everything together
        self.vbox.show_all()
        
        # Closing the dialog
        self.connect("response", lambda x, y: self.close())
        self.connect("close", lambda x: self.close())
        
    def close(self):
        self.tray.config = None
        self.destroy()
        
    def make_cbox(self):
        cbe = gtk.combo_box_entry_new_text()
        cbe.append_text("disabled")
        for t in self.tray.keyword_actions.keys():
            cbe.append_text(t)
        return cbe

    def make_frame(self, title):
        f = gtk.Frame()
        lbl = gtk.Label()
        lbl.set_markup("<b>%s</b>" %title)
        lbl.set_padding(0, 4)
        f.set_label_widget(lbl)
        f.set_shadow_type(gtk.SHADOW_NONE)
        a = gtk.Alignment(xscale=1.0)
        a.set_padding(0, 0, 12, 0)
        f.add(a)
        return f

    def hotkey_changed(self, which):
        self.conf.set_string("/apps/eee-control-tray/hotkeys/hotkey-%s" %which.get_name(), which.get_active_text())
        
    def notify_changed(self, which):
        self.conf.set_bool("/apps/eee-control-tray/notify/%s" %which.get_name(), which.get_active())
    
    def autofsb_changed(self, widget):
        self.conf.set_bool("/apps/eee-control-tray/options/autofsb", widget.get_active())

    def fan_control_changed(self, widget):
        self.conf.set_bool("/apps/eee-control-tray/options/fan_control", widget.get_active())
        # We can safely ignore DBus errors here
        try: self.iface.set_fan_control(widget.get_active())
        except: pass

