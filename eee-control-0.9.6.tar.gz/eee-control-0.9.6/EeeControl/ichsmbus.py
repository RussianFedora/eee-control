#
# Copyright (c) 2008 Grigori Goronzy <greg@geekmind.org>
#
# Permission to use, copy, modify, and distribute this software for any
# purpose with or without fee is hereby granted, provided that the above
# copyright notice and this permission notice appear in all copies.
#
# THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
# WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
# ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
# WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
# ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
# OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
#

# This module implements user-space access to the i801 compatible SMBus
# controllers found on all recent Intel chipsets.
# Only what is needed for eee-control so far, e.g. block transfers, are
# supported.
#
# TODO: Semaphore handling

import ioport

# Controller constants
SMB_BASE = 0x400        # This is only an assumption, but should be always true.
SMBHSTSTS = SMB_BASE
SMBHSTCNT = SMB_BASE + 2
SMBHSTCMD = SMB_BASE + 3
SMBHSTADD = SMB_BASE + 4
SMBHSTDAT0 = SMB_BASE + 5
SMBHSTDAT1 = SMB_BASE + 6
SMBBLKDAT = SMB_BASE + 7
SMBAUXSTS = SMB_BASE + 12
SMBAUXCTL = SMB_BASE + 13

SMBHSTERRMASK = 0x1c

I801_BLOCK_DATA = 0x14
I801_START = 0x40

"""validate smbus address"""
def addr_validate(addr):
    return not ((addr < 0) or (addr > 0x7f))

"""validate smbus command"""
def cmd_validate(cmd):
    return not ((cmd < 0) or (cmd > 0xff))
    
def smbus_init():
    # Accessing ports < 0x400 needs special privileges    
    ioport.iopl(3)
    # Try to identify whether there's "something" at 0x400 with the status register
    ioport.outb(0xff, SMBHSTSTS)
    if ioport.inb(SMBHSTSTS) & 0x01:
        return False
    return True
    
def smbus_read_block(addr, command):
    if addr_validate(addr) == False:
        return False
    if cmd_validate(command) == False:
        return False   
    # Clear status register
    ioport.outb(0xff, SMBHSTSTS)
    # Set up command register, slave address register
    addr = (addr << 1) | 0x01       # We're reading data
    ioport.outb(addr, SMBHSTADD)
    ioport.outb(command, SMBHSTCMD)
    # Use block buffer
    ioport.outb(0x02, SMBAUXCTL)
    # Set Data0 and Data1 to sane values
    ioport.outb(32, SMBHSTDAT0) # Read 32 bytes maximum
    ioport.outb(0, SMBHSTDAT1)
    # Send block read command and start reading immediately
    cmd = I801_BLOCK_DATA | I801_START
    ioport.outb(cmd, SMBHSTCNT)
    # Wait for the read to finish
    while (not (ioport.inb(SMBHSTSTS) & 0x02) and not (ioport.inb(SMBHSTSTS) & 0x1c)): pass
    # Check whether the operation was successful
    status = ioport.inb(SMBHSTSTS)
    if (status & SMBHSTERRMASK):
        return False
    # Retrieve the data
    len = ioport.inb(SMBHSTDAT0)
    ioport.inb(SMBHSTCNT)
    data = []
    for i in xrange(len):
        data.append(ioport.inb(SMBBLKDAT))
    return data
    
    
def smbus_write_block(addr, command, data):
    if addr_validate(addr) == False:
        return False
    if cmd_validate(command) == False:
        return False
    if len(data) > 32:
        return False
    # Clear status register
    ioport.outb(0xff, SMBHSTSTS)
    # Set up command register, slave address register
    addr = (addr << 1) | 0x00       # We're writing data
    ioport.outb(addr, SMBHSTADD)
    ioport.outb(command, SMBHSTCMD)
    # Use block buffer
    ioport.outb(0x02, SMBAUXCTL)
    # Set Data0 to length and Data1 to sane value
    ioport.outb(len(data), SMBHSTDAT0)
    ioport.outb(0, SMBHSTDAT1)
    # Fill block buffer with data
    ioport.inb(SMBHSTCNT)
    for b in data:
        ioport.outb(b, SMBBLKDAT)
    # Send block read command and start reading immediately
    cmd = I801_BLOCK_DATA | I801_START
    ioport.outb(cmd, SMBHSTCNT)
    # Wait for the write to finish
    while (not (ioport.inb(SMBHSTSTS) & 0x02) and not (ioport.inb(SMBHSTSTS) & 0x1c)): pass
    # Check whether the operation was successful
    status = ioport.inb(SMBHSTSTS)
    if (status & SMBHSTERRMASK):
        return False
    return True

