#
# Copyright (c) 2009 Grigori Goronzy <greg@geekmind.org>
#
# Permission to use, copy, modify, and distribute this software for any
# purpose with or without fee is hereby granted, provided that the above
# copyright notice and this permission notice appear in all copies.
#
# THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
# WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
# ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
# WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
# ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
# OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
#
#
# This module contains abstractions for the various methods of FSB control
# that are possible.
#
# a) SHE through ACPI
# b) PLL and EC programming through i2c_dev and I/O ports
# c) same, but uses direct I/O access for PLL programming (unsafe?)
#

import os
import time
import re
import ConfigParser
import ichsmbus
import utils
import config
import sys

# Optional
try: import smbus
except ImportError: pass

"""ACPI SHE methods"""
class SHE:
    # Possible locations of the control file
    locations = [
        "/proc/acpi/asus/cpufv",
        "/sys/devices/platform/eeepc/she",
        "/sys/devices/platform/eeepc/cpufv",
    ]
    mapping = {
        2: "powersave",
        1: "normal",
        0: "performance"
    }

    def __init__(self, model, callback):
        self._callback = callback
        self._control = self._find_control()
        self._model = model

        f = open(self._control)
        self._num_presets = int(f.readline(), 0) >> 8
        f.close()

    @staticmethod
    def validate():
        # Try to find location of control file
        return bool(SHE._find_control())

    @staticmethod
    def _find_control():
        for loc in SHE.locations:
            if os.path.exists(loc): return loc
        return False

    # Public interface
    def get_fsb_presets(self):
        presets_dec = sorted([(x, y) for x, y in SHE.mapping.iteritems()])
        presets = [x[1] for x in presets_dec]
        # Some models (Celeron) do not support all three presets
        # Disable the powersave preset for these models
        if self._num_presets < 3: presets.remove(SHE.mapping[2])
        return presets

    def get_fsb(self):
        f = open(self._control)
        i = int(f.readline(), 0) & 3
        f.close()
        return SHE.mapping[i]

    def set_fsb(self, preset):
        if self.get_fsb() == preset: return True
        f = open(self._control, "w")
        for k, v in SHE.mapping.iteritems():
            if v == preset:
                f.write("%s" % k)
                f.close()
                self._callback(preset)
                return True
        return False


"""Additionally undervolt at "normal" setting"""
class SHEUv(SHE):
    def set_fsb(self, preset):
        SHE.set_fsb(self, preset)
        if preset == SHE.mapping[1]:
            utils.ec_gpio_set(utils.EC_VOLTAGE, 0)


"""I2C access through kernel module"""
class I2cDev:
    PLL_ADDR = 0x69
    DEFAULT_STEPWIDTH = 5

    def __init__(self, model, callback):
        self._callback = callback
        self._model = model
        self._conf = ConfigParser.ConfigParser()
        self._read_config()
        self._smbus_init()

        data = self.smbus_read_block(I2cDev.PLL_ADDR, 0)
        data[8] = 0xff        # readback the maximum possible length
        data[0] = 0x01        # And disable spread-spectrum
        self.smbus_write_block(I2cDev.PLL_ADDR, 0, data)
    
    def _smbus_init(self):
        self._smbus = smbus.SMBus(0)

    def _read_config(self):
        self._presets = dict()
        self._stepwidth = I2cDev.DEFAULT_STEPWIDTH
        self._conf.read(config.CONFIG_FILE)
        section = "fsb:%s" % self._model
        if not self._conf.has_section(section): return False
        for k, v in self._conf.items(section):
            if k == "@stepwidth":
                self._stepwidth = int(v)
                continue
            if k == "@parent":
                self._model = v.strip()
                return self._read_config()
            val = map(int, re.split(r"\s+", v.strip()))
            self._presets[k] = val
        return True

    @staticmethod
    def validate():
        if not 'smbus' in sys.modules: return False
        try:
            bus = smbus.SMBus(0)
            bus.read_block_data(I2cDev.PLL_ADDR, 0)
            bus.close()
            return True
        except:
            return False

    def smbus_read_block(self, addr, idx):
        return self._smbus.read_block_data(addr, idx)

    def smbus_write_block(self, addr, idx, data):
        return self._smbus.write_block_data(addr, idx, data)

    # Public interface
    def get_fsb_presets(self):
        presets = [(y[0], x) for x, y in self._presets.iteritems()]
        presets.sort(reverse=True)
        return [x[1] for x in presets]

    def get_fsb(self):
        pll_data = self.smbus_read_block(I2cDev.PLL_ADDR, 0)
        if len(pll_data) < 17:
            log("didn't get enough pll data!")
            return None
        p = pll_data[12]
        for k, v in self._presets.iteritems():
            if v[0] == p: return k
        return self.get_fsb_presets()[0]

    def set_fsb(self, preset):
        if preset not in self._presets.keys():
            return False
        preset_data = self._presets[preset]
        pll_data = self.smbus_read_block(I2cDev.PLL_ADDR, 0)
        pll_data[1] |= (1<<0) | (1<<4) | (1<<6)
        if len(pll_data) < 17:
            log("we didn't get enough pll data!")
            return False
        # M is always 24 for simplicity
        # Adjust N for the new M values
        pll_data[12] = int(24.0/(pll_data[11] & 0x3f) * pll_data[12])
        pll_data[16] = int(24.0/(pll_data[15] & 0x3f) * pll_data[16])
        pll_data[11] = 24
        pll_data[15] = 24
        curr_fsb = pll_data[12]
        curr_pci = pll_data[16]
        target_fsb, target_pci, voltage_flag = preset_data
        if curr_fsb == target_fsb and curr_pci == target_pci: return True
        log("adjustment from %d/%d to %d/%d" %
            (curr_fsb, curr_pci, target_fsb, target_pci))
        # calculate fsb steps
        fsb_dir = self._stepwidth
        pci_dir = self._stepwidth
        # direction
        if curr_fsb > target_fsb: fsb_dir = -fsb_dir
        if curr_pci > target_pci: pci_dir = -pci_dir
        fsb_steps = range(curr_fsb, target_fsb, fsb_dir)
        pci_steps = range(curr_pci, target_pci, pci_dir)
        # add target
        fsb_steps.append(int(target_fsb))
        pci_steps.append(int(target_pci))
        # normalize lists to the same length
        utils.normalize(fsb_steps, pci_steps)
        log("FSB steps: %s" %fsb_steps)
        log("PCI steps: %s" %pci_steps)
        # apply steps
        # set voltage to high during transition
        utils.ec_gpio_set(utils.EC_VOLTAGE, 1)
        for fsb, pci in zip(fsb_steps, pci_steps):
            log("applying step %d/%d" %(fsb, pci))
            time.sleep(0.05)
            pll_data[12] = fsb
            self.smbus_write_block(I2cDev.PLL_ADDR, 0, pll_data)
            pll_data[16] = pci
            time.sleep(0.05)
            self.smbus_write_block(I2cDev.PLL_ADDR, 0, pll_data)
        # restore voltage flag
        utils.ec_gpio_set(utils.EC_VOLTAGE, voltage_flag)
        self._callback(preset)
        return True


"""Direct I/O access"""
class DirectIo(I2cDev):
    def _smbus_init(self):
        ichsmbus.smbus_init()
    
    @staticmethod
    def validate():
        return ichsmbus.smbus_init()

    def smbus_read_block(self, addr, idx):
        return ichsmbus.smbus_read_block(addr, idx)

    def smbus_write_block(self, addr, idx, data):
        return ichsmbus.smbus_write_block(addr, idx, data)


"""Dummy implementation"""
class Dummy:
    def __init__(self, model, callback): pass
    @staticmethod
    def validate(): return True
    def get_fsb_presets(self): return ["none"]
    def get_fsb(self): pass
    def set_fsb(self): pass


METHOD = {
    "she": SHE,
    "she-uv": SHEUv,    # SHE plus undervolting
    "i2c-dev": I2cDev,
    "direct-io": DirectIo,
}

