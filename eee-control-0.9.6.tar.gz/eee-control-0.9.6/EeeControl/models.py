#
# Copyright (c) 2008-2009 Grigori Goronzy <greg@geekmind.org>
#
# Permission to use, copy, modify, and distribute this software for any
# purpose with or without fee is hereby granted, provided that the above
# copyright notice and this permission notice appear in all copies.
#
# THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
# WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
# ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
# WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
# ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
# OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
#

import os

class EeePc700:
    def __init__(self, action):
        self.action = action
        # FIXME: some 700s have a camera, some don't        
        self.features = "wifi", "reader", "camera", "touchpad"

        # Settings for extended brightness range.
        # superhigh is on the safe side to not kill your backlight.
        self.extended_brightness = True
        self.brightness_superlow = 0x05
        self.brightness_superhigh = 0xc0
        
        self.action_map = {
            0x10: self.action.wifi_toggle,
            0x11: self.action.wifi_toggle,
            0x13: self.action.mute,
            0x14: self.action.vol_down,
            0x15: self.action.vol_up,
        }
        
        self.hotkey_map = {
            0x30: "(Fn-F5)",
            0x12: "(Fn-F6)",
        }

        # FIXME: Check if we're using the ath5k module on Kernel 2.6.27 or
        # later. If set self.wlan_module="ath5k", self.wlan_dev="wlan0"
        self.wlan_module = "ath_pci"
        self.wlan_dev = "ath0"

    def wifi_off(self):
        # rfkill is still very flaky, at least with rt2860sta
        # it often freezes the machine after toggling.
        if bool(self.wlan_dev):
            os.spawnlp(os.P_WAIT, "ifconfig", "ifconfig", self.wlan_dev, "down")
        if bool(self.wlan_module):
            os.spawnlp(os.P_WAIT, "modprobe", "modprobe", "-r", self.wlan_module)
        if self.wlan_path.find("rfkill") == -1: pass
        if os.path.exists(self.wlan_path):
            f = open(self.wlan_path, "w")
            f.write("0\n")
            f.close()

    def wifi_on(self):
        if os.path.exists(self.wlan_path):
            f = open(self.wlan_path, "w")
            f.write("1\n")
            f.close()
        if self.wlan_path.find("rfkill") == -1: pass
        if bool(self.wlan_module):
            os.spawnlp(os.P_WAIT, "modprobe", "modprobe", self.wlan_module)


class EeePc700SE(EeePc700):
    def __init__(self, action):
        EeePc700.__init__(self, action)
        
        self.wlan_module = "r8180"
        self.wlan_dev = "wlan0"


class EeePc900(EeePc700):
    def __init__(self, action):
        EeePc700.__init__(self, action)

        self.features = "wifi", "reader", "camera", "touchpad"
        self.extended_brightness = True


class EeePc900A(EeePc900):
    def __init__(self, action):
        EeePc900.__init__(self, action)
        
        self.features = "wifi", "reader", "camera", "touchpad"


class EeePc901(EeePc700):
    def __init__(self, action):
        self.action = action
        
        # TODO: think of a method to recognize 901go
        # maybe possible through eeepc_laptop control files
        # note that 901go doesn't have bluetooth
        
        self.features = "wifi", "bt", "reader", "camera", "touchpad"
        
        # Settings for extended brightness range.
        # superhigh is on the safe side to not kill your backlight.
        self.extended_brightness = True
        self.brightness_superlow = 0x20
        self.brightness_superhigh = 0xd0
        
        self.action_map = {
            0x10: self.action.wifi_toggle,
            0x11: self.action.wifi_toggle,
            0x13: self.action.mute,
            0x14: self.action.vol_down,
            0x15: self.action.vol_up,
        }
        
        self.hotkey_map = {
            0x1a: "Hotkey 1",
            0x1b: "Hotkey 2",
            0x1c: "Hotkey 3",
            0x1d: "Hotkey 4",
            0x30: "(Fn-F5)",
            0x12: "(Fn-F6)",
        }

        self.wlan_module = "rt2860sta"
        self.wlan_dev = "ra0"


class EeePc1000(EeePc901):
    def __init__(self, action):
        EeePc901.__init__(self, action)

        self.extended_brightness = False
        self.hotkey_map = {
            0x1a: "Hotkey 1",
            0x1b: "Hotkey 2",
            0x1c: "Hotkey 3",
            0x1d: "Hotkey 4",
            0x16: "(Fn-F7)",
            0x30: "(Fn-F8)",
            0x12: "(Fn-F9)",
        }


class EeePc1000HE(EeePc1000):
    def __init__(self, action):
        EeePc1000.__init__(self, action)
        self.hotkey_map = {
            0x39: "Hotkey",
            0x1a: "Hotkey 1",
            0x1b: "Hotkey 2",
            0x1c: "Hotkey 3",
            0x1d: "Hotkey 4",
            0x37: "(Fn-F3)",
            0x1b: "(Fn-F4)",
            0x16: "(Fn-F7)",
            0x30: "(Fn-F8)",
            0x12: "(Fn-F9)",
        }
        self.wlan_module = "ath9k"
        self.wlan_dev = "wlan0"


class EeePc1000HD(EeePc1000):
    def __init__(self, action):
        EeePc1000.__init__(self, action)

        self.wlan_module = "ath5k"
        self.wlan_dev = "wlan0"


class EeePc1002HA(EeePc1000HE):
    def __init__(self, action):
        EeePc1000HE.__init__(self, action)
        self.action_map = {
            0x10: self.action.wifi_toggle,
            0x11: self.action.wifi_toggle,
            0x13: self.action.mute,
            0x14: self.action.vol_down,
            0x15: self.action.vol_up,
        }

class EeePc904HD(EeePc900):
    def __init__(self, action):
        EeePc900.__init__(self, action)
        self.hotkey_map = {
            0x1a: "Hotkey 1",
            0x1b: "Hotkey 2",
            0x1c: "Hotkey 3",
            0x1d: "Hotkey 4",
            0x16: "(Fn-F7)",
            0x30: "(Fn-F8)",
            0x12: "(Fn-F9)",
        }


class EeePcAutodetect:
    def __init__(self, action):
        self.action = action
        self.extended_brightness = False
        self.brightness_superlow = 0
        self.brightness_superhigh = 0
        self.features = ["wifi", "bt", "touchpad"]
        self.action_map = {
            0x10: self.action.wifi_toggle,
            0x11: self.action.wifi_toggle,
            0x13: self.action.mute,
            0x14: self.action.vol_down,
            0x15: self.action.vol_up,
        }
        # Cram everything into the mapping
        self.hotkey_map = {
            0x39: "Hotkey",
            0x37: "(Fn-F3)",
            0x1a: "Hotkey 1",
            0x1b: "Hotkey 2",
            0x1c: "Hotkey 3",
            0x1d: "Hotkey 4",
            0x16: "(Fn-F7)",
            0x30: "(Fn-F8/F5)",
            0x12: "(Fn-F9/F6)",
        }
        self.detect_features()

    def detect_features(self):
        features = {
            "camera": "camera",
            "cardr": "reader",
        }

        for k, v in features.iteritems():
            if os.path.exists(os.path.join(self.action.acpi_base, k)):
                self.features.append(v)

    # This does not care about the special needs of crappy drivers
    # like rt2860sta -- let's just hope it will not blow up
    def wifi_off(self):
        if os.path.exists(self.wlan_path):
            f = open(self.wlan_path, "w")
            f.write("0\n")
            f.close()

    def wifi_on(self):
        if os.path.exists(self.wlan_path):
            f = open(self.wlan_path, "w")
            f.write("1\n")
            f.close()


# Map system-product-name to the abstractions
MODEL_MAP = {
    "700": EeePc700,
    "700SE": EeePc700SE,
    "701SD": EeePc700SE,
    "701": EeePc700,
    "900": EeePc900,
    "900SD": EeePc900,
    "900HD": EeePc900,
    "904HD": EeePc904HD,
    "904HA": EeePc901,
    "900A": EeePc900A,
    "900HA": EeePc900A,
    "901": EeePc901,
    "1000": EeePc1000,
    "1000H": EeePc1000,
    "1000HV": EeePc1000HE,
    "1000HD": EeePc1000HD,
    "1000HE": EeePc1000HE,
    "1002HA": EeePc1002HA,
    "1008HA": EeePc1002HA,
    "1005HA": EeePc1002HA,
    "702": EeePc700,
    "AUTODETECT": EeePcAutodetect,
}
