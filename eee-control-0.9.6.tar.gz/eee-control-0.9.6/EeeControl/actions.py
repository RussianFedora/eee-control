#
# Copyright (c) 2008-2009 Grigori Goronzy <greg@geekmind.org>
#
# Permission to use, copy, modify, and distribute this software for any
# purpose with or without fee is hereby granted, provided that the above
# copyright notice and this permission notice appear in all copies.
#
# THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
# WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
# ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
# WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
# ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
# OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
#

import os, sys
import gobject
import math
import signal
import struct
import socket
import dbus.service
import models
import ioport
import time
import glob
import utils
import config
import she
import ConfigParser

#--------------------------------------------------------------------------

"""Receive and parse ACPI events"""
class AcpiParser:
    def __init__(self, model):
        self.model = model
        self.event_types = ("ATKD", "ASUS010:00")
        # Try to connect, and if it fails, simulate a hangup
        try: self.connect()
        except socket.error: self.hangup_acpi(None, None)
         
    def connect(self):
        # Open connection to acpid socket
        asg = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        asg.connect(utils.ACPID_SOCKET)
        gobject.io_add_watch(asg, gobject.IO_IN, self.read_acpi)
        gobject.io_add_watch(asg, gobject.IO_HUP, self.hangup_acpi)
        log("connected to acpid")
            
    def read_acpi(self, source, cond):
        line = source.recv(1024)
        # Sometimes after the connection gets dropped we still are called...
        if not line: return False
        args = line.strip().split(" ")
        if len(args) != 4: return True
        typ, source, code, serial = args
        if typ == "hotkey" and source in self.event_types:
            key = int(code, 16)
            log("received hotkey 0x%x" %key)
            self.model.do_action(key)
        # A "processor" event appears always after wakeups, but also when
        # switching from battery to ac, and vice versa.
        # It's a hack, but seems to be good enough.
        elif typ == "processor":
            log("re-configuring hardware")
            self.model.reconfig()
        return True
    
    """Poll for acpid re-appearance every 10 seconds"""
    def hangup_acpi(self, source, cond):
        log("acpid disconnected")
        gobject.timeout_add(10000, self.try_reconnect)
        return False
    
    """Try to reconnect -- if successful, remove timeout"""
    def try_reconnect(self):
        log("trying to reconnect to acpid")
        try: self.connect()
        except socket.error: return True
        return False
        

"""Eee PC hardware actions"""
class EeeActions(dbus.service.Object):
    def __init__(self, conn, manu, model, acpi_base, brn_path, bt_path, wlan_path, hwkey_control, obj_path="/org/eee/Eee/EeePc"):
        dbus.service.Object.__init__(self, conn, obj_path)
        self.fakekey_dev = open(glob.glob("/dev/input/by-path/platform-*-kbd")[0], "w")
        
        # Configuration
        self._config = ConfigParser.ConfigParser()
        self._config.read(config.CONFIG_FILE)
        # Insert default values for all non-specified fields
        for name, section in config.DEFAULTS.iteritems():
            if not self._config.has_section(name):
                self._config.add_section(name)
            for k, v in section.iteritems():
                if not self._config.has_option(name, k):
                    self._config.set(name, k, v)
        
        self.fan_control = self._config.getboolean("general", "fan-control")
        method = self._config.get("general", "fsb-method").strip()
        # for autodetection, always use she
        if model == "AUTODETECT" and method not in ("she", "she-uv"):
            method = "she"
        if (method in she.METHOD) and she.METHOD[method].validate():
                self.fsb = she.METHOD[method](model, self.fsb_changed)
        else:
                log("FSB control method not found or invalid, using dummy fallback")
                self.fsb = she.Dummy(model, self.fsb_changed)
        
        self.fan_max_speed = self._config.getint("fan", "max-speed")
        self.fan_interval = self._config.getint("fan", "interval")
        self.fan_critical = self._config.getint("fan", "critical-temperature")
        
        # Set up EC address space
        #ioport.ioperm(utils.EC_BASE, 4, 1)
        ioport.iopl(3)
    
        # We don't need to deal with the sound/brightness keys anymore
        # when eeepc_laptop is used
        self.hwkey_control = hwkey_control

        self.acpi_base = acpi_base
        self.brn_path = brn_path
        self.bt_path = bt_path
        self.wlan_path = wlan_path

        # The wlan module and device are populated by the model definitions
        self.wlan_module = ""
        self.wlan_interface = ""

        self.model_string = model
        self.manufacturer_string = manu
        # Initialize model
        my_model = models.MODEL_MAP[self.model_string]
        self.model = my_model(self)
        self.model.wlan_path = self.wlan_path

        # WiFi overrides
        if self._config.has_option("general", "wlan-module"):
            log("overriding WiFi module")
            self.model.wlan_module = self._config.get("general", "wlan-module").strip()
        if self._config.has_option("general", "wlan-device"):
            log("overriding WiFi device")
            self.model.wlan_dev = self._config.get("general", "wlan-device").strip()

        # Extended brightness overrides
        if (self.model.extended_brightness and not
        self._config.getboolean("brightness", "extended-brightness")):
            log("disabling brightness overdrive")
            self.model.extended_brightness = False

        if self._config.has_option("brightness", "minimum"):
            br = self._config.get("brightness", "minimum")
            self.model.brightness_superlow = int(br, 0) 
        if self._config.has_option("brightness", "maximum"):
            br = self._config.get("brightness", "maximum")
            self.model.brightness_superhigh = int(br, 0)

        # Does the bluetooth path really exist?
        # Some model variants do not have bluetooth...
        if not self.bt_path:
            self.model.features = filter(lambda x: x != "bt", self.model.features)
            self.bt_path = "/dev/null"

        # Initialize state
        self.brn_state = self.get_brightness() + 0x20
        self.brn_ext_state = 0
        self.fan_timeout = False
        self.last_fsb = None
        
        # Fan control?
        if self.fan_control: self.start_fan_control()

    """Generalized on/off switching"""
    @dbus.service.method("org.eee.Eee")
    def set_feature(self, what, status):
        if what in self.model.features:
            if status == True:
                what = what + "_on"
            else:
                what = what + "_off"
            try:
                m = getattr(self, what)
            except AttributeError:
                return False
            m()
            return True
        else:
            return False
    
    @dbus.service.method("org.eee.Eee")
    def get_feature(self, what):
        if what in self.model.features:
            try:
                m = getattr(self, "get_%s" % what)
            except AttributeError:
                return False
            return m()
        return False
            
    """Execute an action according to ACPI keycode"""
    def do_action(self, code):
        # The screen switch button runs through 0x30..0x32
        if code in (0x30, 0x31, 0x32): code = 0x30
        # On/Off hardware switches
        if code in self.model.action_map.keys():
            log("executing action %s" %self.model.action_map[code].__name__)
            self.model.action_map[code]()
        # Brightness
        elif code in range(0x20, 0x30):
            if self.brn_state < code:
                self.brn_up()
                self.brn_state = code
            elif self.brn_state > code:
                self.brn_down()
                self.brn_state = code
            # Brightness overdrive
            elif code == 0x20 and self.brn_state == 0x20:
                self.brn_down()
            elif code == 0x2f and self.brn_state == 0x2f:
                self.brn_up()
        # Programmable hotkeys
        elif code in self.model.hotkey_map:
            self.hotkey_pressed(code, self.model.hotkey_map[code])

    """Reconfigure hardware after wakeup from suspend"""
    def reconfig(self):
        self.set_fsb(self.last_fsb)
        if self.fan_timeout:
            self.stop_fan_control()
            self.start_fan_control()

    """ Fake a keypress """
    @dbus.service.method("org.eee.Eee")
    def fakekey(self, key):
        b = struct.pack("xxxxxxxxHHixxxxxxxxHHi", 1, key, 1, 1, key, 0)
        self.fakekey_dev.write(b)
        self.fakekey_dev.flush()
        
    """Initialize brightness from current value"""
    def get_brightness(self):
        if not os.path.exists(self.brn_path):
            log("cannot access brightness path: %s" %self.brn_path)
            exit(1)

        f = open(self.brn_path)
        l = f.readline()
        brn = int(l.strip()) + 0x20
        f.close()
        log("brightness state is %x" %brn)
        return brn
    
    """Get back a boolean value from a file in /proc"""
    def get_bool(self, path):
        f = open(path)
        l = f.readline()
	if l == "": return False
        b = bool(int(l.strip()))
        f.close()
        return b
    
    """Fan control with sigmoid function"""
    def start_fan_control(self):
        log("starting automatic fan control")
        self.fan_running = False
        # Be careful to always restore automatic adjustment when exiting!
        for s in (signal.SIGTERM, signal.SIGHUP, signal.SIGINT):
            signal.signal(s, self.fan_safe_exit)
        if self.fan_timeout: return # Already running...
        # Intialize with a low fan speed
        self.set_fan_manual(25)
        self.update_fan()
        self.fan_timeout = gobject.timeout_add(utils.FAN_TIMEOUT, self.update_fan)
    
    def stop_fan_control(self):
        log("stopping automatic fan control")
        if self.fan_timeout: gobject.source_remove(self.fan_timeout)
        self.fan_timeout = False
        self.set_fan_auto()
        for s in (signal.SIGTERM, signal.SIGHUP, signal.SIGINT):
            signal.signal(s, signal.SIG_DFL)
    
    def fan_safe_exit(self, x, y):
        log("fan control safe exit")
        self.set_fan_auto()
        sys.exit(0)
    
    def update_fan(self):
        temp = utils.ec_read(utils.EC_REG_TEMP)
        speed = int(self.fan_max_speed*1.0/(1+math.exp(
            -(temp-self.fan_critical)/self.fan_interval)))
        log("auto fan speed %d" %speed)
        # Everything below 15 is considered off
        if speed < 15:
            speed = 0
            self.fan_running = False
        # Below 20 we will "kick the fan into gear"
        # by spinning it up for a second
        #  -- but only if it isn't already running
        elif speed < 20 and self.fan_running == False:
            log("kicking fan")
            self.fan_running = True
            gobject.timeout_add(1000, self.fan_kick, speed)
            speed = 30
        utils.ec_write(utils.EC_REG_FANPWM, speed)
        return True
    
    """Return fan to the real speed after kick-into-gear"""
    def fan_kick(self, speed):
        # if fan control has been stopped in the meantime, do nothing
        # ...but remember to unregister the timeout
        if self.fan_timeout == False:
            return False
        utils.ec_write(utils.EC_REG_FANPWM, speed)
        return False
        
    """Emit a signal that a hotkey was pressed for the frontend"""
    @dbus.service.signal("org.eee.Eee")
    def hotkey_pressed(self, hotkey, descr):
        log("hotkey is %s" %descr)

    @dbus.service.method("org.eee.Eee")
    def mute(self):
        if self.hwkey_control:
            #self.fakekey(config.VOLUME_MUTE)
            pass

    @dbus.service.method("org.eee.Eee")
    def vol_down(self):
        if self.hwkey_control:
            #self.fakekey(config.VOLUME_DOWN)
            pass

    @dbus.service.method("org.eee.Eee")
    def vol_up(self):
        if self.hwkey_control:
            #self.fakekey(config.VOLUME_UP)
            pass

    def brn_down(self):
        log("lowering brightness")
        if self.brn_state == 0x20 and self.model.extended_brightness:
            log("applying superlow brightness")
            self.brn_ext_state = -1
            self.pci_config("0000:00:02.1", 0xf4, self.model.brightness_superlow)
        elif self.brn_ext_state == 1:
            self.brn_ext_state = 0
        else:
            #self.fakekey(config.BRIGHTNESS_DOWN)
            pass

    def brn_up(self):
        log("upping brightness")
        if self.brn_state == 0x2f and self.model.extended_brightness:
            log("applying superhigh brightness")
            self.brn_ext_state = 1
            self.pci_config("0000:00:02.1", 0xf4, self.model.brightness_superhigh)
        elif self.brn_ext_state == -1:
            self.brn_ext_state = 0
        else:
            #self.fakekey(config.BRIGHTNESS_UP)
            pass
    
    """Modify a register in the PCI config space. Be careful here."""
    def pci_config(self, device, register, value):
        f = open("/sys/bus/pci/devices/%s/config" %device, "r")
        buf = f.read(256)
        f.close()
        bufs = [c for c in buf]
        bufs[register] = chr(value)
        buf = "".join(bufs)
        f = open("/sys/bus/pci/devices/%s/config" %device, "w")
        f.write(buf)
        f.close()

    @dbus.service.method("org.eee.Eee")
    def wifi_toggle(self):
        if self.get_bool( self.wlan_path ):
            self.model.wifi_off()
            self.wifi_changed(False)
        else:
            self.model.wifi_on()
            self.wifi_changed(True)

    # These actions are not accessible through default hardware keys    
    @dbus.service.method("org.eee.Eee")
    def bt_off(self):
        f = open(self.bt_path, "w")
        f.write("0\n")
        f.close()
        self.bluetooth_changed(False)

    @dbus.service.method("org.eee.Eee")
    def bt_on(self):
        f = open(self.bt_path, "w")
        f.write("1\n")
        f.close()
        self.bluetooth_changed(True)

    @dbus.service.method("org.eee.Eee")
    def cam_off(self):
        f = open(os.path.join(self.acpi_base, "camera"), "w")
        f.write("0\n")
        f.close()
        self.camera_changed(False)

    @dbus.service.method("org.eee.Eee")
    def cam_on(self):
        f = open(os.path.join(self.acpi_base, "camera"), "w")
        f.write("1\n")
        f.close()
        self.camera_changed(True)

    @dbus.service.method("org.eee.Eee")
    def reader_off(self):
        f = open(os.path.join(self.acpi_base, "cardr"), "w")
        f.write("0\n")
        f.close()
        self.reader_changed(False)

    @dbus.service.method("org.eee.Eee")
    def reader_on(self):
        f = open(os.path.join(self.acpi_base, "cardr"), "w")
        f.write("1\n")
        f.close()
        self.reader_changed(True)
    
    """Set FSB using the chosen access method"""
    @dbus.service.method("org.eee.Eee")
    def set_fsb(self, preset):
        # This can take some time, especially with the SHE method and/or
        # Celeron CPUs. Therefore, schedule it to be executed via a
        # timeout and return immediately.
        self.last_fsb = preset
        gobject.timeout_add(0, self.set_fsb_real, preset)        

    def set_fsb_real(self, preset):
        self.fsb.set_fsb(preset)
        return False
        
    @dbus.service.method("org.eee.Eee")    
    def set_fan_auto(self):
        utils.ec_write(utils.EC_REG_FEATURE, utils.ec_read(utils.EC_REG_FEATURE) & ~0x02)
        self.fan_auto()

    @dbus.service.method("org.eee.Eee")    
    def set_fan_manual(self, speed):
        if speed < 0: speed = 0
        if speed > 100: speed = 100
        log("setting fan to %d" % speed)
        utils.ec_write(utils.EC_REG_FEATURE, utils.ec_read(utils.EC_REG_FEATURE) | 0x02)
        utils.ec_write(utils.EC_REG_FANPWM, speed)        
        self.fan_manual(speed)

    @dbus.service.method("org.eee.Eee")    
    def touchpad_off(self): 
        f = open("/sys/bus/serio/drivers/psmouse/bind_mode", "w")
        f.write("manual")
        f.close()
        f = open("/sys/bus/serio/drivers/psmouse/unbind", "w")
        f.write("serio1")
        f.close()
        self.touchpad_changed(False)

    @dbus.service.method("org.eee.Eee")    
    def touchpad_on(self):
        f = open("/sys/bus/serio/drivers/psmouse/bind_mode", "w")
        f.write("auto")
        f.close()
        self.touchpad_changed(True)
    
    @dbus.service.signal("org.eee.Eee")
    def wifi_changed(self, status): pass

    @dbus.service.signal("org.eee.Eee")
    def bluetooth_changed(self, status): pass

    @dbus.service.signal("org.eee.Eee")
    def camera_changed(self, status): pass

    @dbus.service.signal("org.eee.Eee")
    def reader_changed(self, status): pass

    @dbus.service.signal("org.eee.Eee")
    def fsb_changed(self, descr): pass
    
    @dbus.service.signal("org.eee.Eee")
    def fan_auto(self): pass

    @dbus.service.signal("org.eee.Eee")
    def fan_manual(self, speed): pass
    
    @dbus.service.signal("org.eee.Eee")
    def touchpad_changed(self, status): pass

    @dbus.service.method("org.eee.Eee")
    def get_wifi(self): return self.get_bool(self.wlan_path)

    @dbus.service.method("org.eee.Eee")
    def get_bluetooth(self): return self.get_bool(self.bt_path)

    @dbus.service.method("org.eee.Eee")
    def get_camera(self): return self.get_bool(os.path.join(self.acpi_base, "camera"))

    @dbus.service.method("org.eee.Eee")
    def get_reader(self): return self.get_bool(os.path.join(self.acpi_base, "cardr"))
    
    @dbus.service.method("org.eee.Eee")
    def get_fan(self): return bool(ec_read(EC_REG_FEATURE) & 0x02) 

    @dbus.service.method("org.eee.Eee")
    def get_fan_speed(self):
        rpm = utils.ec_read(utils.EC_REG_FANSPEED+1) | (
            utils.ec_read(utils.EC_REG_FANSPEED) << 8)  
        speed = utils.ec_read(utils.EC_REG_FANPWM)
        return speed, rpm

    @dbus.service.method("org.eee.Eee")
    def get_temperature(self):
        return utils.ec_read(utils.EC_REG_TEMP)
    
    @dbus.service.method("org.eee.Eee")
    def get_touchpad(self): return os.path.exists("/sys/bus/serio/drivers/psmouse/serio1")

    @dbus.service.method("org.eee.Eee")
    def get_fsb(self):
        return self.fsb.get_fsb()

    @dbus.service.method("org.eee.Eee")
    def get_fsb_presets(self):
        return self.fsb.get_fsb_presets()
    
    @dbus.service.method("org.eee.Eee")
    def get_hotkeys(self):
        return self.model.hotkey_map
    
    @dbus.service.method("org.eee.Eee")
    def info(self):
        return (utils.VERSION, "%s %s" %(self.manufacturer_string, self.model_string))
    
    @dbus.service.method("org.eee.Eee")
    def set_fan_control(self, state):
        if state == True and self.fan_control == False:
            self.start_fan_control()
        elif state == False and self.fan_control == True:
            self.stop_fan_control()
        self.fan_control = state
        
    @dbus.service.method("org.eee.Eee")
    def get_features(self):
        return self.model.features

