#
# Copyright (c) 2009 Grigori Goronzy <greg@geekmind.org>
#
# Permission to use, copy, modify, and distribute this software for any
# purpose with or without fee is hereby granted, provided that the above
# copyright notice and this permission notice appear in all copies.
#
# THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
# WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
# ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
# WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
# ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
# OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
#

import ioport
import os
import sys

# Embedded controller addresses
EC_BASE = 0x380
EC_REG_TEMP = 0xf451
EC_REG_FANPWM = 0xf463
EC_REG_FANSPEED = 0xf466
EC_REG_FEATURE = 0xf4d3
EC_VOLTAGE = 0x66

# Version string
VERSION = "0.9.6"

# Location of the acpid socket
ACPID_SOCKET = "/var/run/acpid.socket"

# Fan update interval
FAN_TIMEOUT = 15000

"""Get path of resource files indepent of being installed or run in dist"""
def get_file(file):
    if os.path.exists(os.path.join(sys.prefix, "share", "eee-control", file)): return os.path.join(sys.prefix, "share", "eee-control", file)
    else: return os.path.join("data", file)

"""Call a tuple of function plus args"""
def call(p):
    method = p[0]
    args = p[1:]
    return method(*args)

"""normalize two lists to the length of the longer one"""
def normalize(a, b):
    if len(a) == len(b): return
    if len(b) < len(a):
        a, b = b, a
    delta = len(b)-len(a)
    step = len(a) / delta
    pos = 0
    for i in xrange(0, delta):
        obj = 0
        if i == 0: obj = a[0]
        else: obj = a[i-1]
        a.insert(i, obj)
        pos += step

"""Read an embedded controller (EC) reg"""
def ec_read(adr):
    ioport.outb(adr >> 8, EC_BASE+1)
    ioport.outb(adr & 0xff, EC_BASE+2)
    return ioport.inb(EC_BASE+3)

"""Write an embedded controller (EC) reg"""
def ec_write(adr, data):
    ioport.outb(adr >> 8, EC_BASE+1)
    ioport.outb(adr & 0xff, EC_BASE+2)
    ioport.outb(data, EC_BASE+3)

def ec_pin2port(pin):
    return 0xfc20 + ((pin >> 3) & 0x1f)

def ec_pin2mask(pin):
    return 1 << (pin & 0x07)

def ec_gpio_get(pin):
    port = ec_pin2port(pin)
    mask = ec_pin2mask(pin)
    stat = ec_read(port) & mask
    return bool(stat)

def ec_gpio_set(pin, value):
    port = ec_pin2port(pin)
    mask = ec_pin2mask(pin)
    if bool(value) == True:
        ec_write(port, ec_read(port) | mask)
    else:
        ec_write(port, ec_read(port) & ~mask)
