#!/bin/sh

MODULES=/etc/modules
MODPROBED=/etc/modprobe.d/eee-control.conf
ACPI_BACKUP=/etc/acpi/events-old/

# Clean-up configuration
cleanup_file() {
	if [ -e "$1" ]; then
		echo "Cleaning up $1"
		grep '^# Added by eee-control-setup' "$1" >/dev/null
		a=$?
		grep '^# End eee-control-setup' "$1" >/dev/null
		b=$?
		if [ $a -ne 0 -o $b -ne 0 ]; then
			echo "Nothing to clean up"
			return
		fi
		if awk 'BEGIN { skip=0 } /^# Added by eee-control-setup/ { skip=1 } { if (skip==0) print } /^# End eee-control-setup/ { skip=0 }' "$1" >"$1.tmp"; then
			mv "$1.tmp" "$1"
		fi
	fi
}

# "remove" action
if [ "$1" = "remove" ]; then
	cleanup_file $MODULES
	rm -f ${MODPROBED}*
	echo "Moving ACPI scripts back into /etc/acpi/events"
	mv $ACPI_BACKUP/* /etc/acpi/events 2>/dev/null
	rmdir $ACPI_BACKUP 2>/dev/null
	echo "Restarting acpid"
	restart acpid
	exit 0
fi

# Check for module availability
modinfo eeepc_acpi >/dev/null 2>&1
eeepc_acpi_avail=$?
modinfo eeepc_laptop >/dev/null 2>&1
eeepc_laptop_avail=$?


if [ $eeepc_acpi_avail != 0 -a $eeepc_laptop_avail != 0 ]; then
	echo "The module eeepc_acpi or eeepc_laptop, one of them is required, is not available. Please install a suitable kernel (Continuing anyway)."
else
	echo "Kernel module eeepc_acpi/eeepc_laptop found. Good."
fi

date=$(date)

if [ $eeepc_acpi_avail -eq 0 ]; then
	eeepc_module=eeepc-acpi
	blacklist_module=eeepc-laptop
else
	eeepc_module=eeepc-laptop
	blacklist_module=eeepc-acpi
fi

# Add module options
echo "Adding options to $MODPROBED"
cat <<EOF >$MODPROBED
# Added by eee-control-setup
# $date
blacklist asus_eee
blacklist $blacklist_module
options pciehp pciehp_force=1 pciehp_poll_mode=1
options snd_hda_intel power_save=1 power_save_controller=1
# End eee-control-setup
EOF

# Copy config file, but only if it doesn't exist yet
if [ ! -e /etc/eee-control.conf ]; then
    echo "Copying configuration file"
    cp /usr/share/eee-control/eee-control.conf /etc/eee-control.conf
fi

# Move away obsolete ACPI events
echo "Moving conflicting ACPI scripts to $ACPI_BACKUP" 
mkdir -p $ACPI_BACKUP
mv /etc/acpi/events/asus-* $ACPI_BACKUP 2>/dev/null
mv /etc/acpi/events/*eee* $ACPI_BACKUP 2>/dev/null
mv /etc/acpi/events/video_brightness* $ACPI_BACKUP 2>/dev/null
echo "Restarting acpid"
restart acpid

if [ -e /proc/eee ]; then
	echo "Unloading asus_eee for you. Please make sure it isn't auto-loaded on boot!"
	rmmod asus_eee
fi

echo "Loading modules..."
# Unload pciehp now to force loading with the new options
rmmod pciehp 2>/dev/null
for i in pciehp $eeepc_module i2c_i801 i2c_dev; do 
	modprobe $i 2>/dev/null
done

# That's it... for now.
exit 0
