#!/bin/sh

case "$1" in
	250) val=31 ;;
	400) val=33 ;;
	200) val=34 ;;
	*)
		echo "Illegal argument! Possible values are: 200, 250, 400." >&2
		exit 1
	;;
esac

setpci -s 02.0 f0.b=00,60
setpci -s 02.0 f0.b=$val,05
