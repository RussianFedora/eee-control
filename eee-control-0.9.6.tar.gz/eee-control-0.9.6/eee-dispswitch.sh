#!/bin/sh
# eee-dispswitch.sh
# Display switching for Eee PCs with 1024x600 internal resolution

# Query VGA connector. Returns 0 when connected.
vga_query() {
	xrandr -q | grep "VGA1 connected" >/dev/null 2>&1
	return $?
}

# Test whether VGA output is active. Returns 0 when active
vga_active() {
	xrandr -q | grep 'VGA1 connected [0-9]' >/dev/null 2>&1
	return $?
}

# Switch mode depending on option given through command line
case "$1" in
	clone|clone800)
	xrandr --output LVDS1 --mode 800x600 --pos 0x0 --output VGA1 --mode 800x600 --same-as LVDS
	;;

	clone1024)
	xrandr --output LVDS1 --mode 1024x600 --output VGA1 --mode 1024x768 --same-as LVDS1
	xrandr --output LVDS1 --pos 0x84
	;;

	single)
	xrandr --output LVDS1 --mode 1024x600 --pos 0x0 --output VGA1 --off
	;;

	auto)
	if vga_active; then
		$0 single
	elif vga_query; then
		$0 clone
	else
		$0 single
	fi
	;;

	auto1024)
	if vga_active; then
		$0 single
	elif vga_query; then
		$0 clone1024
	else
		$0 single
	fi
	;;

	*)
	echo Usage: $0 "[clone|clone1024|single|auto|auto1024]"
	echo "  clone - clone with 800x600 resolution"
	echo "  clone1024 - clone with 1024x768 resolution, center internal LCD"
	echo "  single - internal LCD screen only"
	echo "  auto - auto-switch between single and clone"
	echo "  auto1024 - same, but use clone1024"
	;;
esac
